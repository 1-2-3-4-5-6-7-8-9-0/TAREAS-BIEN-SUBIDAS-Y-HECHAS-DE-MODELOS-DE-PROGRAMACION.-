//
//  ViewController.swift
//  EJERCICIO NUMERO 1
//
//  Created by Macbook on 06/03/18.
//  Copyright © 2018 macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var Imagen: UIImageView!
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var labelClima: UILabel!
    
    
    @IBAction func slider(_ sender: UISlider) {
        let valor = Int(slider.value * 100)
        let cadena = "\(valor)"
        label.text = cadena
        
        switch valor {
        case 0...20:
            labelClima.text = "Asoleado"
            Imagen.image = UIImage(named: "sun-34485_960_720.jpg")
            
        
            
        case 19...39:
            labelClima.text = "Nubladito"
            Imagen.image = UIImage(named: "images.jpg")
            
            
            
        case 40...59:
            labelClima.text = "Lluviosito"
         Imagen.image = UIImage(named: "Unknown-1.jpg")
            
            
            
        case 60...79:
            labelClima.text = "Granizito"
            Imagen.image = UIImage(named: "Unknown-2.jpg")
            
            
            
        default:
            labelClima.text = "Nievesita"
            
            Imagen.image = UIImage(named: "Unknown-3.jpg")
            
        }

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }




}

