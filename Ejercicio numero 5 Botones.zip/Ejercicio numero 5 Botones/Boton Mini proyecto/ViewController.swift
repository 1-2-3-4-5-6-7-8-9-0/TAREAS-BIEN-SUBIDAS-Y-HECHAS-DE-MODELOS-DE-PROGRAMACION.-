//
//  ViewController.swift
//  EJERCICIO NUMERO 5
//
//  Created by Macbook on 03/05/18.
//  Copyright © 2018 fi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var ejeX: Int = 250
    var ejeY : Int = 400
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor.orange
        
        view.addSubview(boton1)
        view.addSubview(boton2)
        view.addSubview(boton3)
        view.addSubview(boton4)
        view.addSubview(label)
        
        boton1.frame = CGRect(x: 80, y: 530, width: 90, height: 55)
        boton2.frame = CGRect(x: 20, y: 600, width: 90, height: 55)
        boton3.frame = CGRect(x: 130, y: 600, width: 90, height: 55)
        boton4.frame = CGRect(x: 80, y: 660, width: 90 , height: 55)
        label.frame = CGRect(x: ejeX, y: ejeY, width: 50, height: 50)
        
        // Do any additional setup after loading the view.
    }

    var label : UILabel = {
        var label = UILabel()
        label.text = "†"
        label.font = UIFont.systemFont(ofSize: 60)
        label.textColor = UIColor.blue
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    
    
    var boton1: UIButton = {
        var btn = UIButton(type: .system )
        btn.setTitle("Pushale", for: .normal )
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        
        btn.addTarget(self, action: #selector(arriba), for: .touchUpInside)
        btn.backgroundColor = UIColor.white
        btn.layer.cornerRadius = 5
        btn.translatesAutoresizingMaskIntoConstraints = false
        
        return btn
    }()
    
    var boton4: UIButton = {
        var btn = UIButton(type: .system )
        btn.setTitle("Pushale", for: .normal )
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        
        btn.addTarget(self, action: #selector(abajo), for: .touchUpInside)
        btn.backgroundColor = UIColor.white
        btn.layer.cornerRadius = 5
        btn.translatesAutoresizingMaskIntoConstraints = false
        
        return btn
    }()
    
    var boton3: UIButton = {
        var btn = UIButton(type: .system )
        btn.setTitle("Pushale", for: .normal )
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        
        btn.addTarget(self, action: #selector(derecha), for: .touchUpInside)
        btn.backgroundColor = UIColor.white
        btn.layer.cornerRadius = 5
        btn.translatesAutoresizingMaskIntoConstraints = false
        
        return btn
    }()
    
    var boton2: UIButton = {
        var btn = UIButton(type: .system )
        btn.setTitle("Pushale", for: .normal )
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        
        btn.addTarget(self, action: #selector(izquierda), for: .touchUpInside)
        btn.backgroundColor = UIColor.white
        btn.layer.cornerRadius = 5
        btn.translatesAutoresizingMaskIntoConstraints = false
        
        return btn
    }()
    
    
    @objc func test(){
        print("Pushale")
       
    }
    
    @objc func arriba(){
        
        ejeY = ejeY - 10
        
        
        label.frame = CGRect(x: ejeX, y: ejeY, width: 50, height: 50)
        
    }
    
    @objc func abajo(){
        
        ejeY = ejeY + 10
        
        
        label.frame = CGRect(x: ejeX, y: ejeY, width: 50, height: 50)
        
    }
    
    @objc func izquierda(){
        
        ejeX = ejeX - 10
        
        
        label.frame = CGRect(x: ejeX, y: ejeY, width: 50, height: 50)
        
    }
    
    @objc func derecha(){
        
        ejeX = ejeX + 10
        
        
        label.frame = CGRect(x: ejeX, y: ejeY, width: 50, height: 50)
        
    }
    
    
    
  
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
