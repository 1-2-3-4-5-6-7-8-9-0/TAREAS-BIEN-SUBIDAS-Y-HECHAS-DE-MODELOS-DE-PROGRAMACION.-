//
//  Producto.swift
//  EJERCICIO NUMERO 3
//
//  Created by Germán Santos Jaimes on 3/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

struct Producto{
    var nombre: String
    var desc: String
    var precio: Double
    var imagen: String
    var precioAPagar : Double
}

var Ind = 0

let brownies = Producto(nombre: "Brownie", desc: "Pan sabor a chocolate con chocolate en forma de chocolate con holor a chocolate", precio: 6, imagen: "brownies", precioAPagar: 0)

let bagels = Producto(nombre: "Bagels", desc: "Panecito sabrotso", precio: 5, imagen: "bagels", precioAPagar: 0)

let butter = Producto(nombre: "Butter", desc: "Es una esquisites", precio: 5, imagen: "butter", precioAPagar: 0)

let chesse = Producto(nombre: "Chesse", desc: "Rico y delicioso quesobas", precio: 10, imagen: "cheese", precioAPagar: 0)

let coffee = Producto(nombre: "Coffe", desc: "Cafe de la parroquia ", precio: 10, imagen: "coffee", precioAPagar: 0)

let donuts = Producto(nombre: "Donuts", desc: "glaseada la dona", precio: 4.50, imagen: "donuts", precioAPagar: 0)

let cookies = Producto(nombre: "Cookies", desc: "Galletitas con granos de chocolate sabrotso", precio: 8, imagen: "cookies", precioAPagar: 0)

let granola = Producto(nombre: "Granola", desc: "Alimento para personas sanas, para acompañar con tu yoghurt", precio: 3, imagen: "granola", precioAPagar: 0)

let juice = Producto(nombre: "Juice", desc: "Jugo de naranja natural", precio: 15, imagen: "juice", precioAPagar: 0)

let lemonade = Producto(nombre: "Lemonade", desc: "Jugo de limon natural", precio: 12, imagen: "lemonade", precioAPagar: 0)

let lettuce = Producto(nombre: "lettuce", desc: "Lechuga fresca y verdecita", precio: 1.50, imagen: "lettuce", precioAPagar: 0)

let milk = Producto(nombre: "Milk", desc: "Leche sabrotsa", precio: 10, imagen: "milk", precioAPagar: 0)

let onions = Producto(nombre: "Onions", desc: "Cebolla para que llores ju nto a ella", precio: 1.50, imagen: "onions", precioAPagar: 0)

let potato = Producto(nombre: "Potato", desc: "familia del señor cara de papa", precio: 7, imagen: "potato", precioAPagar: 0)

let tea = Producto(nombre: "Tea", desc: "Te de limon calientito o frio", precio: 1.50, imagen: "tea", precioAPagar: 0)

let tomato = Producto(nombre: "Tomato", desc: "Jitomate rojo hermoso", precio: 7, imagen: "tomato", precioAPagar: 0)

let yogurt = Producto(nombre: "Yogurt", desc: "Yogurt de todos los sabores", precio: 9, imagen: "yogurt" , precioAPagar: 0)





var articulos = [brownies, bagels, butter, chesse  , coffee, donuts, cookies, granola, juice, lemonade, lettuce, milk, onions, potato, tea, tomato, yogurt]

